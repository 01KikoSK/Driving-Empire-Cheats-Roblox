import tkinter as tk

class ModMenu:
    def __init__(self, root):
        self.root = root
        self.root.title("Mod Menu")

        self.speed_label = tk.Label(root, text="Vehicle Speed:")
        self.speed_label.pack()

        self.speed_var = tk.DoubleVar()
        self.speed_slider = tk.Scale(root, from_=1.0, to=10.0, resolution=0.1, variable=self.speed_var, orient=tk.HORIZONTAL)
        self.speed_slider.pack()

        self.god_mode_var = tk.BooleanVar()
        self.god_mode_check = tk.Checkbutton(root, text="God Mode", variable=self.god_mode_var)
        self.god_mode_check.pack()

        self.quit_button = tk.Button(root, text="Quit", command=root.quit)
        self.quit_button.pack()

    def update_speed(self, vehicle):
        vehicle.MaxSpeed = self.speed_var.get()

    def enable_god_mode(self, player):
        player.Character.Humanoid.Health = math.inf

root = tk.Tk()
mod_menu = ModMenu(root)
root.mainloop()