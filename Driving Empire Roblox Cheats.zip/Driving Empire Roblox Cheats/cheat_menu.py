import tkinter as tk

def on_button_click():
    print("Button clicked!")

root = tk.Tk()
root.title("Cheat Menu")

# Create a frame for the cheat options
cheat_frame = tk.Frame(root)
cheat_frame.pack(padx=10, pady=10)

# Create a checkbutton for "God mode"
god_mode_var = tk.BooleanVar()
god_mode_checkbutton = tk.Checkbutton(
    cheat_frame,
    text="God mode",
    variable=god_mode_var,
    onvalue=True,
    offvalue=False,
    command=on_button_click
)
god_mode_checkbutton.grid(row=0, column=0, padx=(0, 10))

# Create a checkbutton for "Invisible car"
invisible_car_var = tk.BooleanVar()
invisible_car_checkbutton = tk.Checkbutton(
    cheat_frame,
    text="Invisible car",
    variable=invisible_car_var,
    onvalue=True,
    offvalue=False,
    command=on_button_click
)
invisible_car_checkbutton.grid(row=0, column=1)

# Create a checkbutton for "Super speed"
super_speed_var = tk.BooleanVar()
super_speed_checkbutton = tk.Checkbutton(
    cheat_frame,
    text="Super speed",
    variable=super_speed_var,
    onvalue=True,
    offvalue=False,
    command=on_button_click
)
super_speed_checkbutton.grid(row=0, column=2)

# Create a button to apply the cheats
apply_button = tk.Button(cheat_frame, text="Apply cheats", command=on_button_click)
apply_button.grid(row=1, columnspan=3, pady=(10, 0))

root.mainloop()